#import <Foundation/Foundation.h>

int main (int argc, const char *argv[])
{
    NSLog (@"Hello, Objective-C!");
	
    return (0);
	
} // main
