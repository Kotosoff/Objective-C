#import "CategoryThing.h"

@implementation CategoryThing (Thing2)

- (void) setThing2: (int) t2
{
    thing2 = t2;
} // setThing2


- (int) thing2
{
    return (thing2);
} // thing2

@end // CategoryThing
