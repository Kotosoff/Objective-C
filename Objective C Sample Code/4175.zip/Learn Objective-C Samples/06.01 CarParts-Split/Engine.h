#import <Cocoa/Cocoa.h>

@interface Engine : NSObject
@end // Engine

