#import <Cocoa/Cocoa.h>

@interface Tire : NSObject
@end // Tire
