#import <Cocoa/Cocoa.h>

@interface Engine : NSObject <NSCopying> {
	int horsepower;	
}

@end // Engine

